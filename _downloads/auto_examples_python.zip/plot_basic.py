'''
Basic plotting
==============

'''

import matplotlib.pyplot as plt

plt.plot(range(100))
